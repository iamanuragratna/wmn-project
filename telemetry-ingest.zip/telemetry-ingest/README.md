# telemetry-ingest

Spring Boot telemetry ingest service (Kafka consumer -> Postgres)

## Build
mvn clean package

## Run
java -jar target/telemetry-ingest-0.0.1-SNAPSHOT.jar
