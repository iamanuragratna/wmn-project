package com.wmn.telemetry.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "telemetry")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Telemetry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nodeId;
    private String radioId;
    private OffsetDateTime ts;
    private Integer channel;
    private Integer rssi;
    private Integer snr;
    private Long txBytes;
    private Long rxBytes;
    private Integer txRetries;
    private Integer numClients;
    private Double channelBusyPercent;

    @Column(columnDefinition = "jsonb")
    private String interference;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNodeId() { return nodeId; }
    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
    public String getRadioId() { return radioId; }
    public void setRadioId(String radioId) { this.radioId = radioId; }
    public OffsetDateTime getTs() { return ts; }
    public void setTs(OffsetDateTime ts) { this.ts = ts; }
    public Integer getChannel() { return channel; }
    public void setChannel(Integer channel) { this.channel = channel; }
    public Integer getRssi() { return rssi; }
    public void setRssi(Integer rssi) { this.rssi = rssi; }
    public Integer getSnr() { return snr; }
    public void setSnr(Integer snr) { this.snr = snr; }
    public Long getTxBytes() { return txBytes; }
    public void setTxBytes(Long txBytes) { this.txBytes = txBytes; }
    public Long getRxBytes() { return rxBytes; }
    public void setRxBytes(Long rxBytes) { this.rxBytes = rxBytes; }
    public Integer getTxRetries() { return txRetries; }
    public void setTxRetries(Integer txRetries) { this.txRetries = txRetries; }
    public Integer getNumClients() { return numClients; }
    public void setNumClients(Integer numClients) { this.numClients = numClients; }
    public Double getChannelBusyPercent() { return channelBusyPercent; }
    public void setChannelBusyPercent(Double channelBusyPercent) { this.channelBusyPercent = channelBusyPercent; }
    public String getInterference() { return interference; }
    public void setInterference(String interference) { this.interference = interference; }
}
